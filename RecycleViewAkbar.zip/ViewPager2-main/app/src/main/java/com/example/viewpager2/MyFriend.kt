package com.example.viewpager2

class MyFriend (
    val name: String,
    val phone: String,
    val email: String
)